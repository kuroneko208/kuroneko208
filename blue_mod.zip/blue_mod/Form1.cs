﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace blue_mod
{
    public partial class Form1 : Form
    {
        string outp;
        string org = "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 900, 901, 902, 903, 0, 0, 0, 0, 0, 0, 0, 0, 910, 911, 912, 913, 920, 921, 922, 923, 930, 931, 932, 933, 0, 0, 0, 0, 940, 941, 942, 943, 950, 951, 952, 953, 960, 961, 962, 963, 0, 0, 0, 0, 0, 0, 0, 0, 970, 971, 972, 973, 0, 0, 0, 0]";
        string readd;
        string[] res1 = null;
        
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(Directory.GetCurrentDirectory() + "\\json");

            System.IO.FileInfo[] allFiles = GetAllFileInfo2(dir);
            string b = Directory.GetCurrentDirectory() + "\\json\\" + allFiles[0].ToString();
            string[] mlkey = { "0 Mesh Base", "1 VertexData m_VertexData", "1 TypelessData m_DataSize"};
            string re = Class1.Readjson(b, mlkey);
            readd = re;
            re = re.Substring(1);
            string[] sArray = re.Split(',');

            for(int i = 0; i < sArray.Length; i++)
            {
                sArray[i] = sArray[i].Trim();
            }
            res1 = sArray;
            string str = string.Join("", sArray);
            //string str = string.Join("", lists.ToArray());

            //textBox1.Text = str;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string wr = org;


            int[] sit4 = Class1.mlmath(int.Parse(textBox13.Text));
            wr = wr.Replace("900", sit4[3].ToString());
            wr = wr.Replace("901", sit4[2].ToString());
            wr = wr.Replace("902", sit4[1].ToString());
            wr = wr.Replace("903", sit4[0].ToString());



            int[] sit1 = Class1.mlmath(int.Parse(textBox15.Text));
            wr = wr.Replace("930", sit1[3].ToString());
            wr = wr.Replace("931", sit1[2].ToString());
            wr = wr.Replace("932", sit1[1].ToString());
            wr = wr.Replace("933", sit1[0].ToString());

            //==========
            int[] sit3 = Class1.mlmath(int.Parse(textBox14.Text));
            wr = wr.Replace("920", sit3[3].ToString());
            wr = wr.Replace("921", sit3[2].ToString());
            wr = wr.Replace("922", sit3[1].ToString());
            wr = wr.Replace("923", sit3[0].ToString());

            int[] sit2 = Class1.mlmath(int.Parse(textBox12.Text));
            wr = wr.Replace("960", sit2[3].ToString());
            wr = wr.Replace("961", sit2[2].ToString());
            wr = wr.Replace("962", sit2[1].ToString());
            wr = wr.Replace("963", sit2[0].ToString());

            //========
            for (int i =0;i<4;i++)
            {
                string s = "1";
                if(i == 0)
                {
                    s = "1";
                }
                if (i == 1)
                {
                    s = "4";
                }
                if (i == 2)
                {
                    s = "5";
                }
                if (i == 3)
                {
                    s = "7";
                }

                wr = wr.Replace("9" + s + "0", "0");
                wr = wr.Replace("9" + s + "1", "0");
                wr = wr.Replace("9" + s + "2", textBox10.Text);
                wr = wr.Replace("9" + s + "3", textBox11.Text);
            }
            outp = wr;
            textBox9.Text = wr;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(Directory.GetCurrentDirectory() + "\\json");
            System.IO.FileInfo[] allFiles = GetAllFileInfo2(dir);
            string b = Directory.GetCurrentDirectory() + "\\json\\" + allFiles[0].ToString();
            string[] mlkey = { "0 Mesh Base", "1 VertexData m_VertexData", "1 TypelessData m_DataSize" };
            Class1.Whitejson(b, mlkey, outp);
            

        }
        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            //textBox9.Text = "";

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox12.Text = "2047";
            textBox13.Text = "1495";
            textBox14.Text = "2047";
            textBox15.Text = "1495";
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button1.PerformClick();
            button2.PerformClick();
            button3.PerformClick();
        }


        private void button9_Click(object sender, EventArgs e)
        {

            
            

            int a = (int)(int.Parse(textBox12.Text) * float.Parse(textBox16.Text));
            int b = (int)(int.Parse(textBox13.Text) * float.Parse(textBox16.Text));
            
            textBox14.Text = a.ToString();
            textBox15.Text = b.ToString();
            textBox12.Text = textBox14.Text;
            textBox13.Text = textBox15.Text;
        }





        //EndEvent==========================================================================================//


        System.IO.FileInfo[] GetAllFileInfo2(System.IO.DirectoryInfo dir)
        {
            return dir.GetFiles(".", System.IO.SearchOption.AllDirectories);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox10.Text = "128";
            textBox11.Text = "63";
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        





        //EndClass==========================================================================================//
    }
}
