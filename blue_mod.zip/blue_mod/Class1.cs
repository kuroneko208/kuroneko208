﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace blue_mod
{
    internal class Class1
    {
        public static string Readjson(string jsonfile, string[] key)
        {
           
            using (StreamReader file = File.OpenText(jsonfile))
            {
               
                JObject jObject = JObject.Parse(file.ReadToEnd());
                for (int i = 0; i < key.Length-1; i++)
                {
                    jObject = (JObject)jObject[key[i]];

                }
                string a =jObject[key[key.Length-1]].ToString();
                return a;
            }
        }


        public static string Whitejson(string jsonfile,string[] key, string value)
        {
            string output;
            using (StreamReader file = File.OpenText(jsonfile))
            {

                JObject jObject = JObject.Parse(file.ReadToEnd());
                jObject[key[0]][key[1]][key[2]] = value;
                
                output = JsonConvert.SerializeObject(jObject, Formatting.Indented);
            }

            output = output.Replace("\"[0, 0", "[0, 0");
            output= output.Replace("0, 0]\"", "0, 0]");
            //output = output.Replace("0", "0]");

            File.WriteAllText(jsonfile, output);
           
            return output;
            
        }

        public static int[] mlmath(int inp)
        {
            int[] returns = new int[4];
            int s1 = 63;
            int s2 = 128;
            int s3 = 0;
            int s4 = 0;
            int ad = 128;
            int res1 = 0;
            int res2 = 0;
            int res3 = 0;
            int res4 = 0;
            int cont = 1;
            int x = 1;
            inp = inp - 1;
            for(int i = 0; i < inp; i++)
            {
                if (x == 0)
                {
                    cont = cont * 2;
                    x = cont;
                    ad = ad / 2;
                    if(ad < 1)
                    {
                        ad = 128;
                        for(;i < inp;i++)
                        {
                            if(x == 0)
                            {
                                cont = cont * 2;
                                x= cont;
                                ad = ad / 2;
                            }



                            if (s3 + ad >= 256)
                            {
                                
                                s2++;
                                if(s2 == 256)
                                {
                                    s2 = 0;
                                    s1++;
                                }
                                s3 = s3 + ad - 256;
                            }
                            else
                            {
                                s3 = s3 + ad;
                            }
                            
                            x--;

                        }
                        break;
                       



                    }

                }


                if (s2 + ad>=256)
                {
                    s1++;
                    s2 = s2 + ad - 256;
                }
                else
                {
                    s2 = s2 + ad;
                }
                




                x--; 
            }




            returns[0] = s1;
            returns[1] = s2;
            returns[2] = s3;
            returns[3] = s4;
            return returns;
        }









    }
}
